# Slate Admin Bootstrap Theme
# By alexandredeschamps.ca
# For support requests or suggestions : des.alexandre@gmail.com

# Documentation: 
  Please refer to Documentation.txt

# Credits:

- Source Sans Pro font by Paul D. Hunt/Google Webfonts 
  http://www.google.com/fonts/specimen/Source+Sans+Pro

- Icons by Font Awesome 
  http://fontawesome.io/

- Charts and Graphs using Raphaël & Morris.js
  http://raphaeljs.com/
  http://www.oesmith.co.uk/morris.js/

- Growl Notifications using :
  https://github.com/ifightcrime/bootstrap-growl

# Changes log:

1.0
Initial release